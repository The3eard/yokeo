<?php
/* $servidor = "localhost";
$basedatos = "id13823363_yokeo";
$usuario = "id13823363_useryokeo";
$password = "B]y_5-4Uz*cmwsNq"; */

$servidor = 'localhost';
$basedatos = 'yoquedo';
$usuario = 'root';
$password = '';
